#!/usr/bin/env python3
"""
Main Energy Manager Update System Orchestrator
Coordinates all update components
"""

import os
import sys
import json
import logging
from typing import Dict, Any
from datetime import datetime

# Import our components
from update_checker import EnergyManagerUpdateChecker
from file_merger import EnergyManagerFileMerger
from entity_manager import EntityManager

class MainUpdateSystem:
    
    # Update system version for tracking self-updates
    UPDATE_SYSTEM_VERSION = "1.0.0"
    
    def __init__(self, config_dir: str = "/config"):
        self.config_dir = config_dir
        self.em_dir = os.path.join(config_dir, ".energy_manager")
        
        # Initialize components
        self.update_checker = EnergyManagerUpdateChecker(config_dir, verify_ssl=False)  # Disable SSL verification
        self.file_merger = EnergyManagerFileMerger(config_dir)
        self.entity_manager = EntityManager()
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(self.em_dir, 'main_update.log')),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def check_for_updates(self) -> Dict[str, Any]:
        try:
            result = self.update_checker.check_for_updates()
            
            # Check if update system itself has updates
            if result.get('update_available') and result.get('manifest'):
                manifest = result['manifest']
                system_files = [f for f in manifest.get('files', {}) 
                               if f.startswith('scripts/') and 
                               any(update_file in f for update_file in 
                                   ['update_checker.py', 'file_merger.py', 
                                    'entity_manager.py', 'main_update_system.py'])]
                
                if system_files:
                    result['update_system_files'] = len(system_files)
                    result['system_update_details'] = [
                        manifest['files'][f].get('description', f) for f in system_files
                    ]
                    self.logger.info(f"Update includes {len(system_files)} update system improvements")
            
            # Update Home Assistant entities with results
            if result['update_available']:
                system_note = ""
                if result.get('update_system_files'):
                    system_note = f"\n\n⚙️ This update includes {result['update_system_files']} update system improvements."
                
                self.entity_manager.create_persistent_notification(
                    title="Energy Manager Update Available",
                    message=f"Version {result['remote_version']} is available. Check the Energy Manager dashboard to update.{system_note}",
                    notification_id="em_update_available"
                )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Update check failed: {e}")
            return {'success': False, 'error': str(e)}

    def _update_single_file(self, filepath: str, file_info: Dict, version: str) -> bool:
        local_path = os.path.join(self.config_dir, filepath)
        
        try:
            # Download the file
            temp_path = f"{local_path}.temp"
            if not self.update_checker.download_file(filepath, temp_path):
                return False
            
            # Read the downloaded content
            with open(temp_path, 'r', encoding='utf-8') as f:
                new_content = f.read()
            
            action = file_info.get('action', 'merge')
 
             # Add this debug logging:
            with open('/config/debug_update.txt', 'a') as f:
                f.write(f"[{datetime.now()}] Processing {filepath}\n")
                f.write(f"[{datetime.now()}] Action: {action}\n")
                f.write(f"[{datetime.now()}] Sections: {file_info.get('sections', [])}\n")

            if action == 'replace':
                # Complete file replacement
                with open('/config/debug_update.txt', 'a') as f:
                    f.write(f"[{datetime.now()}] Calling replace_file for {filepath}\n")
                success = self.file_merger.replace_file(local_path, new_content, version)
                
            elif action == 'merge':
                # Section-based merging
                with open('/config/debug_update.txt', 'a') as f:
                    f.write(f"[{datetime.now()}] Calling update_file for {filepath} with merge\n")
                sections = file_info.get('sections', [])
                success = self.file_merger.update_file(local_path, new_content, sections, version)
                
            elif action == 'create':
                # New file creation
                if not os.path.exists(local_path):
                    success = self.file_merger.replace_file(local_path, new_content, version)
                else:
                    self.logger.info(f"File {filepath} already exists, skipping creation")
                    success = True
            
            # Validate YAML files
            if filepath.endswith('.yaml') or filepath.endswith('.yml'):
                if not self.file_merger.validate_yaml_syntax(local_path):
                    success = False
            
            # Clean up temp file
            if os.path.exists(temp_path):
                os.remove(temp_path)
            
            return success
                
        except Exception as e:
            self.logger.error(f"Failed to process {filepath}: {e}")
            return False

    def process_file_updates(self, manifest: Dict) -> bool:
        
        with open('/config/.energy_manager/debug_process.txt', 'w') as f:
            f.write(f"[{datetime.now()}] Starting process_file_updates\n")
            f.write(f"[{datetime.now()}] Files in manifest: {list(manifest.get('files', {}).keys())}\n")
            f.write(f"[{datetime.now()}] Looking for: integrations/mqtt_sensors.yaml\n")
            f.write(f"[{datetime.now()}] Found in manifest: {'integrations/mqtt_sensors.yaml' in manifest.get('files', {})}\n")
              
        success = True
        update_system_files = []
        regular_files = []
        
        # Separate update system files from regular files
        for filepath, file_info in manifest.get('files', {}).items():
            if (filepath.startswith('scripts/') and 
                any(f in filepath for f in ['update_checker.py', 'file_merger.py', 
                                          'entity_manager.py', 'main_update_system.py'])):
                update_system_files.append((filepath, file_info))
            else:
                regular_files.append((filepath, file_info))
        
        # Update regular files first
        for filepath, file_info in regular_files:
            success &= self._update_single_file(filepath, file_info, manifest['version'])
        
        # Update system files last (they take effect next run)
        for filepath, file_info in update_system_files:
            file_success = self._update_single_file(filepath, file_info, manifest['version'])
            if file_success:
                self.logger.info(f"Updated update system file: {filepath} (effective after restart)")
            success &= file_success
        
        # Set restart required flag if update system files were updated
        if update_system_files:
            self.logger.info(f"Updated {len(update_system_files)} update system files - restart required")
            
        return success

    def process_entity_updates(self, manifest: Dict) -> bool:
        success = True
        
        for entity_id, entity_info in manifest.get('entities', {}).items():
            try:
                action = entity_info.get('action')
                
                if action == 'entity_api_update' and 'input_select' in entity_id:
                    # Update input_select options
                    new_options = entity_info.get('payload', {}).get('options', [])
                    preserve = entity_info.get('preserve_current_value', True)
                    success &= self.entity_manager.update_input_select(entity_id, new_options, preserve)
                    
                elif action == 'mqtt_discovery_refresh':
                    # Trigger automation for MQTT discovery
                    automation_id = entity_info.get('automation')
                    if automation_id:
                        success &= self.entity_manager.trigger_automation(automation_id)
                        
            except Exception as e:
                self.logger.error(f"Failed to update entity {entity_id}: {e}")
                success = False
        
        return success

    def handle_special_files(self, manifest: Dict) -> bool:
        try:
            # Check if we need to switch active modbus file
            modbus_files = ['alphaess_modbus.yaml.disabled', 'fronius_modbus.yaml.disabled', 
                           'sigenergy_modbus.yaml.disabled', 'sungrow_modbus.yaml.disabled']
            
            # If any modbus files were updated, ensure the correct one is active
            if any(f in manifest.get('files', {}) for f in modbus_files):
                # Get current inverter brand selection
                brand_state = self.entity_manager.get_entity_state('input_select.inverter_brand')
                if brand_state:
                    current_brand = brand_state.get('state')
                    if current_brand in ['sungrow', 'sigenergy', 'alphaess', 'fronius']:
                        # Copy the appropriate disabled file to modbus.yaml
                        import shutil
                        disabled_file = os.path.join(self.config_dir, f"{current_brand}_modbus.yaml.disabled")
                        active_file = os.path.join(self.config_dir, "modbus.yaml")
                        
                        if os.path.exists(disabled_file):
                            shutil.copy2(disabled_file, active_file)
                            self.logger.info(f"Activated {current_brand} modbus configuration")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to handle special files: {e}")
            return False

    def perform_update(self) -> Dict[str, Any]:
        self.logger.info("Starting Energy Manager update process")
        
        # Check for updates
        update_info = self.check_for_updates()
        if not update_info.get('update_available'):
            return {'success': True, 'message': 'No updates available', 'restart_required': False}
        
        manifest = update_info.get('manifest')
        if not manifest:
            return {'success': False, 'message': 'Failed to download update manifest'}
        
        try:
            self.entity_manager.create_persistent_notification(
                title="Energy Manager Update in Progress",
                message="Update is starting... Please do not restart Home Assistant during this process.",
                notification_id="em_update_progress"
            )
            
            # Process all updates
            file_success = self.process_file_updates(manifest)
            entity_success = self.process_entity_updates(manifest)
            special_success = self.handle_special_files(manifest)
            
            overall_success = file_success and entity_success and special_success
            
            if overall_success:
                # Update version
                self.update_checker.set_current_version(manifest['version'])
                
                self.logger.info(f"Successfully updated to version {manifest['version']}")
                
                # Check if restart is required (if update system files were updated)
                restart_required = any(f.startswith('scripts/') for f in manifest.get('files', {}))
                
                restart_msg = "\n\n⚠️ Please restart Home Assistant to complete the update." if restart_required else ""
                self.entity_manager.create_persistent_notification(
                    title="✅ Energy Manager Update Complete",
                    message=f"Successfully updated to version {manifest['version']}{restart_msg}",
                    notification_id="em_update_complete"
                )
                
                return {
                    'success': True, 
                    'message': f'Successfully updated to version {manifest["version"]}',
                    'restart_required': restart_required
                }
            else:
                # Update failed
                self.entity_manager.create_persistent_notification(
                    title="❌ Energy Manager Update Failed",
                    message="Update failed. Check the logs for details.",
                    notification_id="em_update_failed"
                )
                return {'success': False, 'message': 'Update failed'}
                
        except Exception as e:
            self.logger.error(f"Update process failed: {e}")
            self.entity_manager.create_persistent_notification(
                title="❌ Energy Manager Update Error",
                message=f"Update error: {str(e)}",
                notification_id="em_update_error"
            )
            return {'success': False, 'message': f'Update error: {str(e)}'}

    def rollback_update_system(self, backup_version: str) -> bool:
        try:
            system_files = [
                'scripts/update_checker.py',
                'scripts/file_merger.py', 
                'scripts/entity_manager.py',
                'scripts/main_update_system.py'
            ]
            
            success = True
            for filepath in system_files:
                full_path = os.path.join(self.config_dir, filepath)
                if not self.file_merger.rollback_file(full_path, backup_version):
                    success = False
                    self.logger.error(f"Failed to rollback {filepath}")
                else:
                    self.logger.info(f"Rolled back {filepath} to version {backup_version}")
            
            if success:
                self.entity_manager.create_persistent_notification(
                    title="Update System Rollback Complete",
                    message=f"Update system has been rolled back to version {backup_version}. Please restart Home Assistant.",
                    notification_id="em_system_rollback"
                )
            
            return success
            
        except Exception as e:
            self.logger.error(f"Failed to rollback update system: {e}")
            return False


def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        print("Testing Energy Manager Update System...")
        print("=" * 50)
        
        # Initialize the system
        update_system = MainUpdateSystem()
        
        # Test basic connectivity first
        print(f"Server URL: {update_system.update_checker.server_url}")
        print(f"SSL Verification: {update_system.update_checker.verify_ssl}")
        print(f"Expected version.txt URL: {update_system.update_checker.server_url}/version.txt")
        print(f"Expected manifest.json URL: {update_system.update_checker.server_url}/manifest.json")
        print()
        
        # Check for updates
        result = update_system.check_for_updates()
        print(f"Update check result: {result}")
        print()
        
        if result.get('update_available'):
            print("✅ Updates are available!")
        elif result.get('error'):
            print(f"❌ Error occurred: {result['error']}")
        else:
            print("ℹ️  No updates available.")
            
        # Show some troubleshooting info
        print()
        print("=" * 50)
        print("TROUBLESHOOTING INFO:")
        print("1. Make sure your server is running")
        print("2. Check that these URLs are accessible:")
        print(f"   - {update_system.update_checker.server_url}/version.txt")
        print(f"   - {update_system.update_checker.server_url}/manifest.json")
        print("3. Check server logs for the 500 Internal Server Error")
        print("4. Verify file permissions on your web server")
        print("5. Make sure the directory structure exists on your server")


if __name__ == "__main__":
    main()
